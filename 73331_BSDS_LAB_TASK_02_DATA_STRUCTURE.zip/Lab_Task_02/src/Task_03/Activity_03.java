/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_03;

/**
 *
 * @author Moiz
 */
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class Activity_03 {
    public static void main(String[] args) {      
        Node head = new Node(10);
        head.next = new Node(20);
        head.next.next = new Node(30);
        head.next.next.next = new Node(40);
        head.next.next.next.next = new Node(50);

        System.out.println(" Initial Traversal ");
        display(head);
        
        head = insertAtBeginning(head, 5);
        System.out.println("\n After Inserting 5 at Beginning ");
        display(head);
        
        head = insertAtEnd(head, 60);
        System.out.println("\n After Inserting 60 at End ");
        display(head);
        
        int searchValue = 30;
        boolean found = search(head, searchValue);
        System.out.println("\n Search Result ");
        System.out.println("Is " + searchValue + " present in the list? " + found);
        
        head = deleteNode(head, 20);
        System.out.println("\n After Deleting 20 ");
        display(head);

        System.out.println("\n Final Display ");
        display(head);
    }

    public static void display(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }

    public static Node insertAtBeginning(Node head, int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        return newNode;
    }

    public static Node insertAtEnd(Node head, int data) {
        Node newNode = new Node(data);
        if (head == null) {
            return newNode;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
        return head;
    }

    public static boolean search(Node head, int key) {
        Node current = head;
        while (current != null) {
            if (current.data == key) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public static Node deleteNode(Node head, int key) {
        if (head == null) return null;
        if (head.data == key) {
            return head.next;
        }

        Node current = head;
        while (current.next != null && current.next.data != key) {
            current = current.next;
        }
        
        if (current.next != null) {
            current.next = current.next.next;
        }

        return head;
    }
}

