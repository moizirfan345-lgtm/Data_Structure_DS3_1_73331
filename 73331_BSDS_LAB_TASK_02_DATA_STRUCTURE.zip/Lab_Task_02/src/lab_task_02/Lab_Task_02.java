/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab_task_02;
import java.util.Arrays;
import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class Lab_Task_02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /*int arr[]={45,12,78,9,56,34,89,17,63};
       System.out.println("Traversal :");
      
       for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");*/
       
       int arr[]={45,12,78,9,56,34,89,17,63};
        /*int sum = 0;
        int max = arr[0];
        int min = arr[0];
        
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
            if (arr[i] > max) {
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        double average = (double) sum / arr.length;
        
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);
        System.out.println();*/
        
        
        /*int newValue = 58; 
        int insertIndex = 3; 
        
        int[] insertionResult = new int[arr.length + 1];
        
        for (int i = 0; i < insertionResult.length; i++) {
            if (i < insertIndex) {
                insertionResult[i] = arr[i];
            } else if (i == insertIndex) {
                insertionResult[i] = newValue;
            } else {
                insertionResult[i] = arr[i - 1]; 
            }
        }
        System.out.println("Insertion (Inserted " + newValue + " at index " + insertIndex + "):");
        System.out.println("   " + Arrays.toString(insertionResult));
        System.out.println();*/
        
        
        
        
        /*int deleteIndex = 7;
        
        int[] deletionResult = new int[arr.length - 1];
        
        for (int i = 0; i < arr.length; i++) {
            if (i < deleteIndex) {
                deletionResult[i] = arr[i];
            } else if (i > deleteIndex) {
                deletionResult[i - 1] = arr[i];
            }
        }
        System.out.println("Elemnet Deleted at index " + deleteIndex);
        System.out.println("   " + Arrays.toString(deletionResult));*/
        
        
                            /*2D Array*/
                            
                           /* int i,j;*/
        
        /*Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of rows: ");
        int rows = scanner.nextInt();
        
        System.out.print("Enter the number of columns: ");
        int cols = scanner.nextInt();
        
        
        int[][] matrix = new int[rows][cols];
       
        System.out.println("Enter the elements of the array:");
        for ( i = 0; i < rows; i++) {
            for ( j = 0; j < cols; j++) {
                System.out.print("Element at [" + i + "][" + j + "]: ");
                matrix[i][j] = scanner.nextInt();
                                            
            } 
        }
        System.out.println("Display Array");    
       for(i=0; i<rows; i++){
           for(j=0;j<cols;j++){
               System.out.println(matrix[i][j] + "\t");
           }
           System.out.println();
       }
       
       int totalSum = 0;
       int max = matrix[0][0];
       int min = matrix[0][0];
       int totalElements = rows * cols;
       
         for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
       
           totalSum += matrix[i][j];
           
           if (matrix[i][j]>max){
               max = matrix[i][j];
           }
           if(matrix[i][j]<min){
               min = matrix[i][j];
           }
        }
         }
         double average = (double) totalSum/totalElements;
         System.out.println("Total Sum : " + totalSum);
         System.out.println("Maximum : " + max);
         System.out.println("Minimum : "  + min);
         System.out.println("Average : " + average);
         
       System.out.println("Rows Sum");
       for(i=0; i<rows; i++){
           int rowsSum = 0;
           for(j=0;j<cols;j++){
            rowsSum += matrix[i][j];   
           }
           System.out.println("Sum of Rows : " + i + " : " + rowsSum);
       }
       
       System.out.println("Columns Sum");
       
       for(j=0; j<cols; j++){
           int sumCols = 0;
           for(i=0; i<rows; i++){
               sumCols += matrix[i][j];
               
           }
           System.out.println("Sum of Columns : "  + j + " : "  + sumCols);
       }*/
       
       
                            /*3D Array*/
                            
       Scanner scanner = new Scanner(System.in);

        int i, j, k;   
        
        System.out.println("Enter Number of Layers : ");
        int Layers = scanner.nextInt();
        
        System.out.println("Enter the Number of Rows :  ");
        int Rows = scanner.nextInt();
        
        
       System.out.println("Enter Number of Columns :  ");
       int Cols = scanner.nextInt();
       
       
       int[][][] array = new int[Layers][Rows][Cols];
       
       
       System.out.println("\nEnter the Number of Elements : ");
       
      for(i=0; i<Layers; i++){
          System.out.println("Layers : " + i);
          
          for(j=0;j<Rows;j++){
              for(k=0; k<Cols; k++){
                  
                  System.out.println("Elements at : [ " + i +"][" + j + "][" + k + "] : ");
                  
                  array[i][j][k] = scanner.nextInt();
              }
          }
      }
      
      
      System.out.println("\nDisplay 3D Array");
      
      for(i=0; i<Layers; i++){
          System.out.println("Layers " + i + "  :  ");
          
          for(j=0; j<Rows; j++){
              for(k=0; k<Cols; k++){
                  
                  
                System.out.println(array[i][j][k] + "\t");
              }
              
              System.out.println();
          }
          System.out.println();
      }
      
      int totalSum = 0;
      int totalElements = Layers * Rows * Cols;
      
      int max  = array[0][0][0];
      int min  = array[0][0][0];
      
      for(i=0; i<Layers; i++){
          for(j=0; j<Rows; j++){
              for(k=0; k<Cols; k++){
                  
                  
                  totalSum += array[i][j][k];
                  
                  if (array[i][j][k]>max){
                      max = array[i][j][k];
                  }
                  
                  if (array[i][j][k]<min){
                      
                      min = array[i][j][k];
                  }
              }
          }
      }
      
      
      
      double average = (double) totalSum/totalElements;
      
      System.out.println("Total Sum : " + totalSum);
      System.out.println("Maximum :  " + max);
      System.out.println("Minimum : " + min);
      System.out.println("Average : " + average);
      
      
      System.out.println("Sum of each Layer :");
      
      for(i=0; i<Layers; i++){
      int LayerSum = 0;
      
      for(j=0; j<Rows; j++){
          for(k=0; k<Cols; k++){
              
              LayerSum += array[i][j][k];
              
          }
      }
      
      System.out.println("Sum of Layers : " + i + " = " + LayerSum);
      } 
      System.out.println("Enter the Value to Search : ");
      
      int search = scanner.nextInt();
      
      boolean found = false;
      
      for(i=0; i<Layers; i++){
          for(j=0; j<Rows; j++){
              for(k=0; k<Cols; k++){
                  
                  if(array[i][j][k] == search ){
                      
                      
                      
                        System.out.println("Value found at:");
                        System.out.println("Layer : " + i);
                        System.out.println("Row : " + j);
                        System.out.println("Column : " + k);

                        found = true;
                  }
              }
          }
      }
      
      if (!found) {
            System.out.println("Value not found in the 3D array.");
        }
    }
       
    }


       
