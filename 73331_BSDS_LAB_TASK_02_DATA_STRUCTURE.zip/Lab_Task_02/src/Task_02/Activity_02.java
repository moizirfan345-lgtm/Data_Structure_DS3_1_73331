/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_02;
import java.util.Arrays;
import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class Activity_02 {
    public static void displayArray(int[] arr, String message){
        System.out.println(message);
        for(int num : arr){
            System.out.print(num + "  ");
        }
        System.out.println();
    }
    
    
    public static void bubbleSort(int[]arr){
        int i,j,k;
        int[] sortedArr = Arrays.copyOf(arr,arr.length);
        int n = sortedArr.length;
        
        System.out.println("\n Bubble Sort ");
        
        displayArray(sortedArr, " Original Array");
        
        for( i=0; i<n-1; i++){
            for(j=0; j<n-i-1;j++){
              if(sortedArr[j] > sortedArr[j + 1]){
                  
                  int temp = sortedArr[j];
                  sortedArr[j] = sortedArr[j + 1];
                  sortedArr[j + 1] = temp;
                  
              }  
            }
        }
        
        displayArray(sortedArr, "Sorted Array:");
        
    }
    
    
    public static void selectionSort(int[] arr) {
        int[] sortedArr = Arrays.copyOf(arr, arr.length);
        int n = sortedArr.length;
        
        System.out.println("\n SELECTION SORT");
        displayArray(sortedArr, "Original Array:");
        
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;         
          
            for (int j = i + 1; j < n; j++) {
                if (sortedArr[j] < sortedArr[minIndex]) {
                    minIndex = j;
                }
            }
                        
            int temp = sortedArr[minIndex];
            sortedArr[minIndex] = sortedArr[i];
            sortedArr[i] = temp;
        }
        
        displayArray(sortedArr, "Sorted Array:");
    }
        
    public static void insertionSort(int[] arr) {
        int[] sortedArr = Arrays.copyOf(arr, arr.length);
        int n = sortedArr.length;
        
        System.out.println("\n INSERTION SORT");
        displayArray(sortedArr, "Original Array:");
        
        for (int i = 1; i < n; i++) {
            int key = sortedArr[i];
            int j = i - 1;
                        
            while (j >= 0 && sortedArr[j] > key) {
                sortedArr[j + 1] = sortedArr[j];
                j = j - 1;
            }
            sortedArr[j + 1] = key;
        }
        
        displayArray(sortedArr, "Sorted Array:");
    }
        
    public static void main(String[] args) {
        int[] array = {64, 25, 12, 22, 11, 90, 34};
        
        System.out.println("SORTING ALGORITHMS DEMONSTRATION");        
        System.out.println("Original Array: " + Arrays.toString(array));
                
        bubbleSort(array);
        selectionSort(array);
        insertionSort(array);
        
    }
    
}
