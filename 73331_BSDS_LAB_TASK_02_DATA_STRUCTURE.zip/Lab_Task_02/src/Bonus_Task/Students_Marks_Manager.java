/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bonus_Task;
import java.util.Arrays;
/**
 *
 * @author Moiz
 */
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class Students_Marks_Manager {
  public static void main(String[] args) {
        int[] marks = {85, 42, 95, 60, 78};
        System.out.println(" Array Marks ");
        System.out.println(Arrays.toString(marks));

        int max = marks[0], min = marks[0], sum = 0;
        for (int m : marks) {
            if (m > max) max = m;
            if (m < min) min = m;
            sum += m;
        }
        double avg = (double) sum / marks.length;
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);
        System.out.println("Average: " + avg);

        Arrays.sort(marks);
        System.out.println("Sorted Array: " + Arrays.toString(marks));

        Node head = null;
        for (int m : marks) {
            head = insertEnd(head, m);
        }
        System.out.println("\n Linked List from Array ");
        displayList(head);

        head = insertEnd(head, 90);
        System.out.println("After Inserting 90:");
        displayList(head);

        head = deleteNode(head, 42);
        System.out.println("After Deleting 42:");
        displayList(head);

        System.out.println("\n Final Contents ");
        System.out.println("Final Array: " + Arrays.toString(marks));
        System.out.print("Final Linked List: ");
        displayList(head);
    }

    public static Node insertEnd(Node head, int data) {
        Node newNode = new Node(data);
        if (head == null) return newNode;
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
        return head;
    }

    public static Node deleteNode(Node head, int key) {
        if (head == null) return null;
        if (head.data == key) return head.next;
        Node current = head;
        while (current.next != null && current.next.data != key) {
            current = current.next;
        }
        if (current.next != null) {
            current.next = current.next.next;
        }
        return head;
    }

    public static void displayList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }  
}
