/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_02;
 import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class Activities {
   public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    /*System.out.print("Enter marks: ");
    int marks = input.nextInt();
    
    System.out.println("Marks = " + marks);
    if (marks >= 85)
    System.out.println("A");
    else if (marks >= 70)
    System.out.println("B");
    else if (marks >= 50)
    System.out.println("C");
    else
    System.out.println("Fail");*/
    
    /*System.out.println("1.Insert");
    System.out.println("2.Delete");
    System.out.println("Invalid Choice");
    
    int choice = input.nextInt();
    switch (choice) {
    case 1:
        System.out.println("Insert");
        break;
    case 2:
        System.out.println("Delete");
        break;
    default:
        System.out.println("Invalid choice");
}*/
    
    
    } 
} 

