/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_02;
import java.util.Scanner;

/**
 *
 * @author Moiz
 */
public class Student_Exercise {
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
    
    
                                //STUDENT EXERCISES
                                
                                
                                
         /*System.out.print("Enter first number: ");
        int a = input.nextInt();
        
        System.out.print("Enter second number: ");
        int b = input.nextInt();
        
        if (a > b) {
            System.out.println("The larger value is: " + a);
        } else if (b > a) {
            System.out.println("The larger value is: " + b);
        } else {
            System.out.println("Both numbers are equal.");
        }      */
         
         
        /* System.out.print("Enter student marks: ");
        int marks = input.nextInt();
        System.out.print("Enter attendance percentage: ");
        int attendance = input.nextInt();
     
        if (marks >= 50 && attendance >= 75) {
            System.out.println("Status: Eligible for the exam.");
        } else {
            System.out.println("Status: Not eligible.");
        }*/
        
       /*System.out.print("Enter a number for the day of the week: ");
        int dayNumber = input.nextInt();
        
        switch (dayNumber) {
            case 1:
                System.out.println("Monday");
                
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            case 7:
                System.out.println("Sunday");
                break;
            default:
                System.out.println("Invalid input. Please enter a number between 1 and 7.");
                break;
        } */
       
        
}
}
