/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_02;
import java.util.Scanner;

/**
 *
 * @author Moiz
 */
public class ChallengeTask {
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);     
        System.out.println("--- Calculator Menu ---");
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Multiplication");
        System.out.println("4. Division");
        System.out.print("Select an operation (1-4): ");
        int choice = input.nextInt();
        System.out.print("Enter first number: ");
        double a = input.nextDouble();    
        System.out.print("Enter second number: ");
        double b = input.nextDouble();
        switch (choice) {
            case 1:
                System.out.println("Result: " + (a + b));
                break;
            case 2:
                System.out.println("Result: " + (a - b));
                break;
            case 3:
                System.out.println("Result: " + (a * b));
                break;
            case 4:
                if (b == 0) {
                    System.out.println("Error: Cannot divide by zero!");
                } else {
                    System.out.println("Result: " + (a / b));
                }
                break;
            default:
                System.out.println("Invalid selection. Please run the program again and choose 1-4.");
                break;
        }   
}
}
