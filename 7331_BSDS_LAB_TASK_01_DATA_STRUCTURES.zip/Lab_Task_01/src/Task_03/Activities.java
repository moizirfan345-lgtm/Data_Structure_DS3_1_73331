/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_03;
import java.util.Scanner;

/**
 *
 * @author Moiz
 */
public class Activities {
    public static void main(String[] args) {
   
    /*int i = 1;
    while (i <= 5) {
    System.out.println(i);
    i++;
}*/
    
    /*int i = 1;
    do {
    System.out.println(i);
    i++;
    } 
    while (i <= 5);
*/
    /*int n = 8;
    int sum = 0;
    for (int i = 1; i <= 8; i++) {
    sum += i;
}
    System.out.println(sum);*/
    
    /*double[] values = {2.5, 3.0, 4.5};
    double sum = 0;

    for (double value : values) {
    sum += value;
    }
    System.out.println(sum);*/
    
    
   /* for (int i = 1; i <= 10; i++) {
    if (i == 5)
        continue;
    if (i == 9)
        break;
    System.out.println(i);
}*/

    }  
}
