/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_03;
import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class Student_Exercises {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    /*int count = 10;    
        while (count >= 1) {
            System.out.println(count);
            count--;}   */
    
    
    
    /*int number;
        
        do {
            System.out.print("Enter a positive number: ");
            number = input.nextInt();
        } 
        while (number <= 0);
        
        System.out.println("Thank you! You entered a valid positive number: " + number);*/
    
    
       /* System.out.print("Enter a number to find its factorial: ");
        int n = input.nextInt();        
        long factorial = 1;        
        for (int i = 1; i <= n; i++) {
            factorial = factorial * i;
        }  
        System.out.println("The factorial of " + n + " is: " + factorial);*/
       
       
      /* int[] numbers = {12, 45, 7, 891, 233, 568};
       int max = numbers[0]; 
        
        for (int num : numbers) {
            if (num > max) {
                max = num;
            }
        }        
        System.out.println("The maximum value in the array is: " + max);*/
      
      
      /*for (int i = 1; i <= 20; i++) {
            if (i % 3 == 0) {
                continue;
            }
            System.out.println(i);*/
      
      /*while (true) { 
            System.out.print("Enter a number : ");
            int num = input.nextInt();
            
            if (num == -1) {
                System.out.println("Loop terminated by user.");
                break; 
            }            
            System.out.println("You entered: " + num);*/
      
    }
}

