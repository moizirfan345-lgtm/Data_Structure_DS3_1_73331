/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_03;
import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class ChallengeTask {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    /*System.out.print("Enter the number of courses : ");
        int n = input.nextInt();
        
        int[] marks = new int[n];
        int sum = 0;
        int max = 0;
        for (int i = 0; i < n; i++) {
            System.out.print("Enter marks for course " + (i + 1) + ": ");
            marks[i] = input.nextInt();
            
            sum = sum + marks[i];
                  
            if (i == 0 || marks[i] > max) {
                max = marks[i];
            }
        }
        
        int passedCourses = 0;
        for (int mark : marks) {
            if (mark >= 50) {
                passedCourses++;
            }
        }
        
        System.out.println("\n--- Marks Summary ---");
        System.out.println("Total Sum: " + sum);
        System.out.println("Maximum Marks: " + max);
        System.out.println("Courses with at least 50 marks: " + passedCourses);*/
    
    }
}
