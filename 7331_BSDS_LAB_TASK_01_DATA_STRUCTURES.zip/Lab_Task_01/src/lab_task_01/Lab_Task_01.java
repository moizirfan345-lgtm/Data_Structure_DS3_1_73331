/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab_task_01;

/**
 *
 * @author Moiz
 */
public class Lab_Task_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*System.out.println("Welcome to Data Structures Lab");*/
        /*int age = 20;
        double cgpa = 3.25;
        char grade = 'A';
        boolean passed = true;

        System.out.println(age);
        System.out.println(cgpa);
        System.out.println(grade);
        System.out.println(passed);*/
        /*int x = 10;
        x = x + 5;
        x++;
        System.out.println(x);*/
        
        
        
        
                        /*STUDENT EXERCISE*/
                        
                        
                        
       /* String name = "Muhammad Moiz Irfan";
        int semesterNumber = 1; 
        double cgpa = 3.5;

        System.out.println("Name: " + name);
        System.out.println("Semester: " + semesterNumber);
        System.out.println("CGPA: " + cgpa);     */
       
       
        /*int a = 20;
        int b = 5;

        System.out.println("Sum: " + (a + b));
        System.out.println("Difference: " + (a - b));
        System.out.println("Product: " + (a * b));
        System.out.println("Quotient: " + (a / b));*/
        
        
        /*String studentName = "Moiz";
        String DegreeName = "BS Data Science";
        int rollNumber = 73331;
        char section = 'A';
        boolean isFeePaid = true;

        System.out.println("Student: " + studentName);
        System.out.println("Degree : " + DegreeName );
        System.out.println("Roll Number : " + rollNumber );
        System.out.println("Section : " + section);
        System.out.println("Fee Status : " + isFeePaid);*/
        
        
        //int 1stSemesterMarks = 85; .
        //int firstSemesterMarks = 85;

        //System.out.println("First Semester Marks: " + firstSemesterMarks);
    
        
                                        //CHALLENGE TASK
                                        
                                        
        /*String studentName = "Muhammad Moiz Irfan"; 
        int semester = 1;                           
        double cgpa = 3.75;                         
        char section = 'A';                        
        boolean isEnrolled = true;                
        
        System.out.println("       STUDENT INFORMATION       ");
        System.out.println("Name:            " + studentName);
        System.out.println("Semester:        " + semester);
        System.out.println("Section:         " + section);
        System.out.println("Current CGPA:    " + cgpa);
        System.out.println("Enrolled Active: " + isEnrolled);*/
    }
}
