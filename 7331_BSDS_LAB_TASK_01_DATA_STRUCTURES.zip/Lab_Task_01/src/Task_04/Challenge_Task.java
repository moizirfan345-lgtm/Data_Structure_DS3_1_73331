/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_04;

/**
 *
 * @author Moiz
 */
class BankAccount {
    String accountHolderName;
    double balance;

    public BankAccount(String name, double initialBalance) {
        accountHolderName = name;
        balance = initialBalance;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Deposited: Rs " + amount + " | New Balance: Rs " + balance);
    }

    public void withdraw(double amount) {
        if (amount > balance)
        {
            System.out.println("Withdrawal Failed! Insufficient funds. Current Balance: Rs " + balance);
        } else {
            balance = balance - amount;
            System.out.println("Withdrew: Rs " + amount + " | New Balance: Rs " + balance);
        }
    }
}
public class Challenge_Task {
    public static void main(String[] args) {
        System.out.println("--- Bank Account System ---");
        BankAccount myAccount = new BankAccount("Moiz", 5000.0);
        
        System.out.println("Account Holder: " + myAccount.accountHolderName);
        System.out.println("Starting Balance: Rs " + myAccount.getBalance());
        
        myAccount.deposit(2000.0); 
        myAccount.withdraw(1500.0); 
        myAccount.withdraw(10000.0); 
    }
}
