/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_04;

/**
 *
 * @author Moiz
 */
class Book {
    String title;
    double price;
    Book(String t, double p)
    { title = t; price = p; }
    void show() { System.out.println(title + " | Rs " + price); }
}

public class Question_03_Student_Excercise {
    public static void main(String[] args) {
        Book book1 = new Book("Java", 1500);
        Book book2 = new Book("Data Science", 2000);

        book1.price = 1200; 

        book1.show(); 
        book2.show(); 
    }    
}
