/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_04;

/**
 *
 * @author Moiz
 */
public class Rectangle {
    double width, height;

    // Constructor
    Rectangle(double w, double h) { width = w; height = h; }

    // Math methods
    double getArea() { return width * height; }
    double getPerimeter() { return 2 * (width + height); }

    // Execution method
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(5, 10);
        
        System.out.println("Area: " + rect.getArea());
        System.out.println("Perimeter: " + rect.getPerimeter());
    }
    
}
