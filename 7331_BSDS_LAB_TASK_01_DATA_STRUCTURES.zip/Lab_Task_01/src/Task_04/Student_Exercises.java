/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_04;

/**
 *
 * @author Moiz
 */
/*class Book {
    String title;
    String author;
    double price;  
    public Book(String t, String a, double p) {
        title = t;
        author = a;
        price = p;
    }
    public void displayInfo() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: Rs " + price);
    }
    public void updatePrice(double newPrice) {
        price = newPrice;
    }
}
public class Student_Exercises {
    public static void main(String[] args) {
        Book myBook = new Book("Java Programming", "Moiz", 1500.0);        
        System.out.println("--- Original Book Info ---");
        myBook.displayInfo();        
        System.out.println("\n--- Updating Price ---");
        myBook.updatePrice(1200.0);
        myBook.displayInfo();
    }
    
}*/


    
