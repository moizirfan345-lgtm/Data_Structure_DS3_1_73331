/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_05;

/**
 *
 * @author Moiz
 */
public class Activities {
    public static void main(String[] args) {
    
    /*int a = 7;
    int b = 2;
    System.out.println(a / b);
    System.out.println((double) a / b);*/
    
    
    
   /* int x = 5;
    System.out.println(x++);
    System.out.println(x);
    System.out.println(++x);*/
   
   
   
    /*int age = 20;
    boolean hasCard = true;

    System.out.println(age >= 18 && hasCard);*/
    
    
    
   /* double d = 9.8;
    int x = (int) d;
    double y = 10;

    System.out.println(x);
    System.out.println(y);*/



    }
}
