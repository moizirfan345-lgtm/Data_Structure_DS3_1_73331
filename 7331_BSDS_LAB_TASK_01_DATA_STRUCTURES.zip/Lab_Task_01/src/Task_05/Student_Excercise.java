/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_05;

/**
 *
 * @author Moiz
 */
public class Student_Excercise {
    public static void main(String[] args) {
        /*int num1 = 10;
        int num2 = 15;
        int num3 = 22;
        
        double average = (num1 + num2 + num3) / 3.0; 
        System.out.println("The average is: " + average);*/
        
        
        /*int x = 10;    
        System.out.println("Starting value of x: " + x);
        System.out.println("Result of x++: " + (x++));
        
        System.out.println("Result of ++x: " + (++x)); 
        System.out.println("Final value of x: " + x);*/
        
        
        
       /* int attendance = 80;
        int marks = 65;
        
        boolean isEligible = (attendance >= 75 && marks >= 50);        
        System.out.println("Attendance: " + attendance + "% | Marks: " + marks);
        System.out.println("Is the student eligible? " + isEligible);       */   
       
       double originalValue = 9.85;
       
       int convertedValue = (int) originalValue; 
        
        System.out.println("Original double value: " + originalValue);
        System.out.println("Converted int value: " + convertedValue);
        System.out.println("Explanation: When converting a double to an int explicitly, the fractional part (.85) is completely dropped. It does NOT round up.");
    }       
    }  

