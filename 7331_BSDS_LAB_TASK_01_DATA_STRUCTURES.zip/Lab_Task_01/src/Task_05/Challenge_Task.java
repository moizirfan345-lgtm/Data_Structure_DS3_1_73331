/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_05;
import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class Challenge_Task {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("--- Mini Grade Calculator ---");
        System.out.print("Enter marks for Subject 1: ");
        int mark1 = input.nextInt();
        
        System.out.print("Enter marks for Subject 2: ");
        int mark2 = input.nextInt();
        
        System.out.print("Enter marks for Subject 3: ");
        int mark3 = input.nextInt();
             
        double average = (mark1 + mark2 + mark3) / 3.0;
              
        boolean isPassed = (average >= 50.0) && (mark1 >= 40 && mark2 >= 40 && mark3 >= 40);
        
        System.out.println("\n--- Grade Report ---");
        System.out.println("Average Score: " + average);
        
        if (isPassed) {
            System.out.println("Status: PASSED! Excellent work.");
        } else {
            System.out.println("Status: FAILED. (Note: Requires an average >= 50 and all individual marks >= 40).");
        }
    }
    
}
