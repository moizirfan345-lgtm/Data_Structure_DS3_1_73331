/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity_02;

/**
 *
 * @author Moiz
 */
public class SortingLab {
public static void main(String[] args) {
        int[] arrayForMerge = {64, 25, 12, 22, 11, 90, 34};
        int[] arrayForQuick = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("---- MERGE SORT ----");
        System.out.print("Before Sorting: ");
        printArray(arrayForMerge);

        mergeSort(arrayForMerge, 0, arrayForMerge.length - 1);

        System.out.print("After Sorting: ");
        printArray(arrayForMerge);

        System.out.println("\n---- QUICK SORT ----");
        System.out.print("Before Sorting: ");
        printArray(arrayForQuick);

        quickSort(arrayForQuick, 0, arrayForQuick.length - 1);

        System.out.print("After Sorting: ");
        printArray(arrayForQuick);
    }

    // ---------- MERGE SORT ----------
    static void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }

    static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        int[] L = new int[n1];
        int[] R = new int[n2];

        for (int i = 0; i < n1; i++) L[i] = arr[left + i];
        for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) arr[k++] = L[i++];
            else arr[k++] = R[j++];
        }
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }

    // ---------- QUICK SORT ----------
    static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    // ---------- UTILITY ----------
    static void printArray(int[] arr) {
        for (int val : arr) System.out.print(val + " ");
        System.out.println();
    }    
}
