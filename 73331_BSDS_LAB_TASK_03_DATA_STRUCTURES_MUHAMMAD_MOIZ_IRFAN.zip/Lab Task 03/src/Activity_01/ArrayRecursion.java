/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity_01;

/**
 *
 * @author Moiz
 */
public class ArrayRecursion {
 public static void main(String[] args) {
        int[] arr = {12, 45, 7, 23, 56, 89, 34};

        System.out.println("Recursive Traversal:");
        printArray(arr, 0);

        int total = sumArray(arr, 0);
        System.out.println("\nSum of array elements: " + total);

        int target = 34;
        int index = searchArray(arr, 0, target);
        if (index != -1) {
            System.out.println("Element " + target + " found at index: " + index);
        } else {
            System.out.println("Element " + target + " not found.");
        }
    }
    static void printArray(int[] arr, int index) {
        if (index == arr.length) return; 
        System.out.print(arr[index] + " ");
        printArray(arr, index + 1); 
    }
    static int sumArray(int[] arr, int index) {
        if (index == arr.length) return 0; 
        return arr[index] + sumArray(arr, index + 1); 
    }
    static int searchArray(int[] arr, int index, int target) {
        if (index == arr.length) return -1;       
        if (arr[index] == target) return index;  
        return searchArray(arr, index + 1, target); 
    }   
}
