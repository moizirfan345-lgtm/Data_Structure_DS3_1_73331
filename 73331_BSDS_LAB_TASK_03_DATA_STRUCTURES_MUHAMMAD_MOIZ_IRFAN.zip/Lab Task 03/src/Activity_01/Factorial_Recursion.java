/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity_01;
import java.util.Scanner;
/**
 *
 * @author Moiz
 */
public class Factorial_Recursion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        int result = factorial(num);
        System.out.println("Factorial of " + num + " is: " + result);
    }

    static int factorial(int n) {
        // Base Case
        if (n == 0 || n == 1) {
            return 1;
        }
        // Recursive Step
        return n * factorial(n - 1);
    }
}
